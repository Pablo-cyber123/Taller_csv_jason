import csv
usuarios = [
    {"id": 1, "nombre": "Ana", "ciudad": "Bogotá"},
    {"id": 2, "nombre": "Pablo", "ciudad": "Medellín"},
    {"id": 3, "nombre": "Juan", "ciudad": "Bogotá"},
    {"id": 4, "nombre": "Marta", "ciudad": "Medellín"},
    {"id": 5, "nombre": "Maria", "ciudad": "Bogotá"},
]


# 2. Escribir usuarios en usuarios.csv
with open("usuarios.csv", "w", newline="") as archivo:
    campos = ["id", "nombre", "ciudad"]
    escritor = csv.DictWriter(archivo, fieldnames=campos)
    escritor.writeheader()
    escritor.writerows(usuarios)

# 3. Leer usuarios y filtrar los de Bogotá
try:
    with open("usuarios.csv", newline="") as archivo:
        lector = csv.DictReader(archivo)
        print("Usuarios de Bogotá:")
        for usuario in lector:
            if usuario["ciudad"] == "Bogotá":
                print(f"ID: {usuario['id']}, Nombre: {usuario['nombre']}, Ciudad: {usuario['ciudad']}")
except FileNotFoundError:
    print("El archivo usuarios.csv no se encuentra. Por favor, asegúrate de que el archivo existe.")
